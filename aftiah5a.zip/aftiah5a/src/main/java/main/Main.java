package main;
import model.AnggotaPerpus;
public class Main {
    
    public static void main(String[] args){
        AnggotaPerpus a= new AnggotaPerpus("5678","aaa","martapura",83158);
        a.update();
//        a.create();
//        a.read();
//        a.setId("1234");
//        a.delete();
//        a.delete("1234");
        
        
        
        
        
        
        
        
        
//        a.setNama("Aftiah");
//        a.setAlamat("Banjarbaru");
//        a.setId(12345);
//        a.setTelp(62831598);
//        
//        System.out.println(a.getNama());
//        System.out.println(a.getId());
//        System.out.println(a.getTelp());
//        System.out.println(a.getAlamat());
    }
    
            
            
}

         